package main


var Banner = 	"ur mother slut\n"
